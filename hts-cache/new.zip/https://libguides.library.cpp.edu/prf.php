<!DOCTYPE html><html lang="en"><head><meta http-equiv="X-UA-Compatible" content="IE=Edge" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><!-- write_head_public.twig -->
<title>
    Profiles - Guides at California State Polytechnic University, Pomona
</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noarchive"/>

<!-- favicon.twig -->
<link rel="apple-touch-icon" sizes="180x180" href="//libapps.s3.amazonaws.com/apps/common/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="//libapps.s3.amazonaws.com/apps/common/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="//libapps.s3.amazonaws.com/apps/common/favicon/favicon-16x16.png">
<link rel="manifest" href="//libapps.s3.amazonaws.com/apps/common/favicon/site.webmanifest">
<link rel="mask-icon" href="//libapps.s3.amazonaws.com/apps/common/favicon/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="//libapps.s3.amazonaws.com/apps/common/favicon/favicon.ico">
<meta name="msapplication-TileColor" content="#ffc40d">
<meta name="msapplication-config" content="//libapps.s3.amazonaws.com/apps/common/favicon/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- !favicon.twig -->

<link rel="stylesheet" href="/web/jquery/css/jquery-ui.min.css?2695"/>
<link rel="stylesheet" href="/web/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="/web/css2.18.6/lg-public.min.css"/>
<script src="/web/jquery/js/1.12.4_jquery.min.js"></script>
<!-- js_include_fallback_lg.twig -->
<script src="//code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script>jQuery.ui || document.write('<script src="/web/jquery/js/jquery-ui.min.js?2695">\x3C/script>');</script>
<!-- !js_include_fallback_lg.twig -->
    <script type="text/javascript"
            src="/web/js2.18.6/lg-public.min.js"></script>
<!-- !write_head_public.twig --><script>
	function searchPrimo() {
		document.getElementById("primoQuery").value = "any,contains," + document.getElementById("primoQueryTemp").value.replace(/[,]/g, " ");
		document.forms["searchForm"].submit();
	}
</script>
<style>
body {
margin: 0;
padding-left: 0;
padding-right: 0;
font-size: 15px;
font-family: sans-serif;
}

/* Changing basic link color for contrast */

.s-lg-tab-content  a {
color: #2449b7 !important;
}

.s-lg-boxnav > li > a  {
color: #2449b7 !important;
}

.s-lib-box-content a {
color: #2449b7 !important;
}

a.btn.btn-info.s-lg-hp-btn-section {
color: #FFF !important;
}

a.label-info {
color: #fff !important;
}

/*******************/
.s-lib-box .s-lib-box-title {
font-size: 16px;
}
.s-lib-box-content p, .s-lib-box-content a {
font-size: 15px;
font-family: sans-serif;
}
#cpp-logobar {
width: 100%;
top: 0;
background-color: rgba(244, 244, 244, 0.9);
transition: background-color .7s;
height: 60px;
line-height: 60px;
padding-left: 15px;
}

.align-middle {
vertical-align: middle !important;
}

#cpp-logo-octo {
left: -25px;
top:-15px;
position: relative;
height: 90px;
}

#cpp-libguides {
margin-bottom: 0px;
}

#cpp-links > li > a {
font-size: 16px;
color: #464a4c;
}

#cpp-links a:hover, #cpp-links a:focus {
text-decoration: underline;
}

div#cpp-search {
background-color: #01426a;
font-size: 16px;
margin-top: 0px;
padding-top: 15px;
padding-bottom: 10px;
}


div#cpp-search a {
color: #FFF;
}

img#onesearch {
margin-top: -5px;
margin-left: 15px;
}

#cpp-form {
margin-top: 12px;
margin-right: 5px;
}

input#primoQueryTemp {
margin-left: 10px;
}
div.search-xtra {
margin-top: 17px;
}

#cpp-lib-footer {
background-color: #01426a;
font-size: 1.45em;
color: #FFF;
font-weight: bold;
}
#cpp-lib-footer a {
color: #ffb500;
}
#cpp-lib-footer a:hover, #cpp-lib-footer a:focus {
color: #fff;
text-decoration: underline:
}
#contact-info {
padding-top: 20px;
padding-bottom: 20px;
}
.lib-icon {
margin-top: 15px;
}

/* Made Librarian name larger in profile box */
.s-lib-profile-name {
font-size: 1.6em;
}

/* Make breadcrumb links larger */
#s-lib-admin-bc .breadcrumb, #s-lib-bc .breadcrumb {
font-size: 12px;
}
</style><script>
var springStats = springStats || {};
springStats.saConfig = springStats.saConfig || {
    site_id: 1071,
    tracking_parameters: {"_st_site_id":1071},
    tracking_server_host: "libguides-proc.springyaws.com"
};
</script>
<script async  src="/web/js/sa.min.js?3116" ></script><script type="text/javascript">
            //====================================================
            springSpace.publicObj = new springSpace.public.Public({
                constant: {
                    PROCESSING: {},
                    CONTENT: {}
                }
            });
            //====================================================
            jQuery(document).ready(function() {
                if (0 == 0) {
                    loadProfileList(0);
                } else {
                    top.window.helptips = new springSpace.sui.helptip({placement: "right"});
                }
                springSpace.UI.xhrPopover();
            });
            //====================================================
            setActiveButton=function(id) {
                jQuery("#s-lg-profile-name-btn").removeClass("active");
                jQuery("#s-lg-profile-subject-btn").removeClass("active");
                jQuery(id).addClass("active");
            }
            //====================================================
            toggleSubjectBoxes=function(subject_id) {
                jQuery("#s-lg-profile-guides-div").html("");

                var is_subject = (subject_id != 0);
                if (is_subject) {
                    xhr = jQuery.ajax({
                        url: "prf_process.php",
                        data: {
                            action: 531,
                            subject_id: subject_id
                        },
                        type: "GET",
                        dataType: "json",
                        success: function(response, textStatus, jqXHR) {
                            if ( response.errCode == 200 ) {
                                jQuery("#s-lg-profile-guides-div").html(response.data.guides);
                            }
                            else {
                                springSpace.UI.error(response.errCode);
                            }
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            springSpace.UI.error(errorThrown);
                        }
                    });
                }

                jQuery("#s-lg-profile-az-div").toggle(!is_subject);
                jQuery("#s-lg-profile-help-div").toggle(!is_subject);
                jQuery("#s-lg-profile-guides-div").toggle(is_subject);
            }
            //====================================================
            loadProfileList=function(subject_id) {
                jQuery("#s-lg-profile-content").html('<div class="bold s-lib-color-lt-grey pad-top-med text-center">Loading...</div>');
                jQuery("#s-lg-profile-count").html(0);

                //set the active button
                setActiveButton(subject_id == 0 ? "#s-lg-profile-name-btn" : "#s-lg-profile-subject-btn");

                // toggle the right hand boxes based on if this is a subject or not
                toggleSubjectBoxes(subject_id);

                // hide the subject view if needed
                if (subject_id == 0) { toggleSubjectView(false); }

                // get the data
                xhr = jQuery.ajax({
                    url: "prf_process.php",
                    data: {
                        action: 530,
                        subject_id: subject_id
                    },
                    type: "GET",
                    dataType: "json",
                    success: function(response, textStatus, jqXHR) {
                        if ( response.errCode == 200 ) {
                            jQuery("#s-lg-profile-content").html(response.data.html);
                            jQuery("#s-lg-profile-count").html(response.data.count);
                        }
                        else {
                            springSpace.UI.error(response.errCode);
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        springSpace.UI.error(errorThrown);
                    }
                });
            }
            //====================================================
            handleSubjectBtnClick=function() {
                jQuery("#s-lg-profile-count").html(0);
                if (!jQuery("#s-lg-profile-subjects").is(":visible")) {
                    jQuery("#s-lg-profile-content").html("");
                }
                toggleSubjectView(true);
            }
            //====================================================
            toggleSubjectView=function(visible) {
                jQuery("#s-lg-profile-subjects").toggle(visible);
                if (visible) { setActiveButton("#s-lg-profile-subject-btn"); }
            }
            //====================================================
            filterBySubject=function(subject_id) {
                toggleSubjectView(true);
                loadProfileList(subject_id);
            }
            //====================================================
            jQuery(function() {jQuery(window).one('load', function() {springSpace.springTrack.trackPage({_st_type_id: '20'});});
            });
        </script><style>
            .pad-left-sm { margin-left:10px; }
            .s-lib-featured-profile-container { width: 160px; margin:0 10px 20px 10px !important; }
            .s-lib-profile-container .s-lib-profile-name, .s-lib-profile-container .s-lib-profile-pronouns { display:none; }
            .s-lib-profile-image { margin-bottom:30px; }
            .s-lg-profile-personal-statement { padding:10px; background-color:#fafafa; border:1px solid #ccc; }
            </style></head><body class="s-lib-public-body">
		<a id="s-lg-public-skiplink" class="alert-info" href="#s-lib-public-main">Skip to Main Content</a>
        <!-- BEGIN: Page Header -->
            <div class="cpp-logobar-min" id="cpp-logobar">
	  <div class="mr-auto">
		<a class="logo align-middle" href="https://www.cpp.edu/index.shtml" id="cpp-header-logo-link"> <img alt="Cal Poly Pomona with Octagon" id="cpp-logo-octo" src="https://libapps.s3.amazonaws.com/customers/1060/images/cpp-octo-web.png"> </a>
	  </div>
	</div>
	<nav class="navbar navbar-default" style="background-color: #fff;" id="cpp-libguides">
  <div class="container-fluid">
	<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	  </button>
	  <a class="navbar-brand" href="https://www.cpp.edu/library/index.shtml" id="brand">
		<img class="img-responsive" alt="University Library" src="https://libapps.s3.amazonaws.com/customers/1060/images/library-justus-small.png" id="logo-img">
	  </a>
	</div>
	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	  <ul class="nav navbar-nav navbar-right" id="cpp-links">
		<li><a href="https://www.cpp.edu/library/library-research-help.shtml">Research Help</a></li>
		<li><a href="https://www.cpp.edu/library/library-services.shtml">Services</a></li>
                <li><a href="https://www.cpp.edu/library/library-spaces-tech.shtml">Spaces &amp; Tech</a></li>
		<li><a href="https://www.cpp.edu/library/library-about.shtml">About</a></li>
		<li><a href="https://www.cpp.edu/library/about/support-library/giving.shtml">Give to the Library</a></li>
	  </ul>
	</div>
  </div>
</nav> <!-- navigation -->
<div class="container-fluid" id="cpp-search">
<div class="row">
  <div class="col-lg-6 col-md-6 12col-sm-12 col-xs-12">
		<form class="form-horizontal" action="https://csu-cpp.primo.exlibrisgroup.com/discovery/search" enctype="application/x-www-form-urlencoded; charset=utf-8" id="simple" method="get" name="searchForm" onsubmit="searchPrimo()" target="_self">
	  <div class="form-group" id="cpp-form">
			<img src="https://libapps.s3.amazonaws.com/customers/1060/images/pomona175.png" class="img-responsive pull-left" alt="OneSearch logo" id="onesearch">
		<div class="input-group">
                <!-- Customizable Parameters -->
                <input type="hidden" name="vid" value="01CALS_PUP:01CALS_PUP" />
                <input type="hidden" name="tab" value="Everything" />
                <input type="hidden" name="search_scope" value="Everything" />
                <input type="hidden" name="lang" value="en" />
                <!-- Fixed parameters -->
                <input type="hidden" name="query" id="primoQuery" />
		  <input class="form-control" id="primoQueryTemp" name="primoQueryTemp" placeholder="Search for books, articles, and more" title="Search CPP Library for books, articles, and more" type="text" />
		  <!-- Search Button -->
		<span class="input-group-btn">
		<button class="btn btn-default" type="button" onclick="searchPrimo()">Go!</button>
	  </span>
		</div>
	  </div>
	</form>
  </div>
  <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 text-center search-xtra"><a href="https://csu-cpp.primo.exlibrisgroup.com/discovery/search?vid=01CALS_PUP:01CALS_PUP&lang=en&mode=advanced">Advanced Search</a></div>
  <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 text-center search-xtra"><a href="https://reserves.calstate.edu/pomona/">Course Reserves</a></div>
  <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 text-center search-xtra"><a href="https://csu-cpp.primo.exlibrisgroup.com/discovery/account?vid=01CALS_PUP:01CALS_PUP">My Library Account</a></div>
</div>
</div>
        <!-- END: Page Header -->
        <!-- BEGIN: Content Header -->
        <div id="s-lib-public-header" class="s-lib-header container s-lib-side-borders">
            <div id="s-lib-bc">
                <ol id="s-lib-bc-list" class="breadcrumb"><li id="s-lib-bc-customer"><a title="University Library" href="http://www.cpp.edu/library">University Library</a></li><li id="s-lib-bc-site"><a title="Guides" href="https://libguides.library.cpp.edu/">Guides</a></li><li id="s-lib-bc-page" class="active">Profiles</li></ol>
            </div>
            <h1 id="s-lib-public-header-title">Profiles</h1>
            <div id="s-lib-public-header-desc">&nbsp;</div>
        </div>
        <!-- END: Content Header -->
        <!-- BEGIN: Nav Bar -->
        <div id="s-lib-public-nav" class="container s-lib-side-borders">
            
        </div>
        <!-- END: Nav Bar -->
        <!-- BEGIN: content -->
        <div id="s-lib-public-main" class="s-lib-main container s-lib-side-borders">
			<!-- profile_navbar.html -->
<div class="clearfix">
    <div id="s-lg-profile-nav">
        <ul>
            <li>
                <ul class="nav nav-pills" style="margin-bottom:0;">
                    <li id="s-lg-profile-count-btn">
                        <span id="s-lg-profile-count" class="badge">0</span> PROFILES
                    </li>
                    <li id="s-lg-profile-name-btn" class="s-lg-index-nav-btn active">
                        <a href="#" onclick="loadProfileList(0);">
                            BY NAME
                        </a>
                    </li>
                    <li id="s-lg-profile-subject-btn" class="s-lg-index-nav-btn">
                        <a href="#" onclick="handleSubjectBtnClick();">
                            BY SUBJECT
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>

            <section>
				<div  id="s-lg-profile-cols"  class="row">
					<div  id="col1"  class="col-md-8 center">
						<div id="s-lg-profile-subjects" style="display:none; margin-bottom:20px;" class="pad-right-sm">
							<!-- profiles_by_subject.twig -->
<div class="col-md-10" style="display:inline-block;">
    <label for="sel-guide-drop" class="sr-only">Please select a subject...</label>
    <select name="sel-guide-drop" id="sel-guide-drop" class="form-control" style="width:100%">
        <option selected value="">Please select a subject...</option>
                    <option value="60012">Accounting</option>
                    <option value="77586">Aerospace Engineering</option>
                    <option value="60013">Agribusiness &amp; Food Industry Management</option>
                    <option value="139681">Agricultural Education</option>
                    <option value="60014">Agriculture</option>
                    <option value="60015">Animal &amp; Veterinary Science</option>
                    <option value="139683">Animal Science</option>
                    <option value="60016">Anthropology</option>
                    <option value="50006">Apparel Merchandising &amp; Management</option>
                    <option value="60017">Architecture</option>
                    <option value="60018">Art</option>
                    <option value="60020">Biological Sciences</option>
                    <option value="60021">Business Administration</option>
                    <option value="77587">Chemical Engineering</option>
                    <option value="60022">Chemistry &amp; Biochemistry</option>
                    <option value="77585">Civil Engineering</option>
                    <option value="50005">Communication</option>
                    <option value="60024">Computer Information Systems</option>
                    <option value="60025">Computer Science</option>
                    <option value="186683">Early Childhood Studies</option>
                    <option value="60026">Economics</option>
                    <option value="60027">Education</option>
                    <option value="77589">Electrical &amp; Computer Engineering</option>
                    <option value="50003">Engineering</option>
                    <option value="77590">Engineering Technology</option>
                    <option value="60028">English</option>
                    <option value="60029">Environmental Design</option>
                    <option value="170883">Ethnic &amp; Women’s Studies</option>
                    <option value="107387">Finance</option>
                    <option value="60031">Food Science</option>
                    <option value="60032">Geography</option>
                    <option value="60033">Geological Sciences</option>
                    <option value="60035">History</option>
                    <option value="60036">Hospitality Management</option>
                    <option value="77591">Industrial &amp; Manufacturing Engineering</option>
                    <option value="60038">Interdisciplinary General Education</option>
                    <option value="60039">International Business</option>
                    <option value="60041">Kinesiology &amp; Health Promotion</option>
                    <option value="80702">Landscape Architecture</option>
                    <option value="60042">Law</option>
                    <option value="121859">Liberal Studies</option>
                    <option value="60043">Management &amp; Human Resources</option>
                    <option value="139676">Marketing</option>
                    <option value="60044">Mathematics &amp; Statistics</option>
                    <option value="77592">Mechanical Engineering</option>
                    <option value="193542">Modern Languages</option>
                    <option value="60045">Music</option>
                    <option value="60037">Nutrition</option>
                    <option value="60046">Philosophy</option>
                    <option value="60047">Physics &amp; Astronomy</option>
                    <option value="60048">Plant Science</option>
                    <option value="60049">Political Science</option>
                    <option value="50004">Psychology</option>
                    <option value="204829">Public Administration</option>
                    <option value="60050">Reference</option>
                    <option value="120142">Regenerative Studies</option>
                    <option value="181168">Science</option>
                    <option value="66368">Social Work</option>
                    <option value="60052">Sociology</option>
                    <option value="193544">Special Collections and Archives</option>
                    <option value="60053">Technology &amp; Operations Management</option>
                    <option value="134318">Theatre &amp; New Dance</option>
                    <option value="60054">Urban &amp; Regional Planning</option>
            </select>
</div>

<div class="col-md-2 pad-left-none" style="display:inline-block;">
    <button type="button" class="btn btn-primary btn-small" onclick="filterBySubject(jQuery('#sel-guide-drop').val());">
        Go
    </button>
</div>

<div style="clear:both;"></div>
<!-- !profiles_by_subject.twig -->

						</div>
						<div id="s-lg-profile-content">
							<div class="bold s-lib-color-lt-grey pad-top-med text-center">Loading...</div>
						</div>
					</div>
                <div  id="col2"  class="col-md-4 center">
                    
					<div id="s-lg-box-6884485-container" class="s-lib-box-container">
						<div id="s-lg-box-6884485" class="s-lib-box s-lib-box-std">
							<h2 class="s-lib-box-title">GET HELP
                                </h2>
							<div id="s-lg-box-collapse-6884485" >
								<div class="s-lib-box-content">
									
			<div id="s-lg-content-13672496" class="  clearfix">
				<div style="height:100%;padding-bottom: 30px;">
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/call-widget_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp;Call us!</h3>

<p><span style="font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;">Call the <a href="https://cpp.service-now.com/library?id=library_article&amp;sys_id=9a0795b3db78df04ae3a567b4b96193f" target="_self">Research Help Desk</a> @ </span><span style=" font-weight: 700; font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;">(909) 869-3084</span><span style="font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;"> </span></p>

<hr />
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/help-widgit_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp; Visit us!</h3>

<p><span style="font-size:14px;"><span style="font-family: Roboto,Arial,serif; line-height: 21px;">Drop in at the <a href="https://cpp.service-now.com/library?id=library_article&amp;sys_id=9a0795b3db78df04ae3a567b4b96193f" target="_self">Research Help Desk</a> </span>on the 2nd Floor of the University Library.</span></p>

<hr />
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/find-widget_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp; Find a Subject Librarian</h3>

<p><span style="font-size:14px;"><span style="font-family: Roboto,Arial,serif; line-height: 21px;"><a href="https://www.cpp.edu/library/reference-instruction/contact-subject-librarian.shtml" target="_self">Subject Librarians</a> </span><span style="font-family: Roboto,Arial,serif; line-height: 21px;"></span>can help with in-depth research</span></p>

<hr />
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/text-widget_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp;Text a Librarian</h3>

<p><span style="font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;">Text or email us at </span><span style="font-weight: 700; font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;"><a href="mailto:libraryhelp@cpp.edu">libraryhelp@cpp.edu</a></span></p>

<hr />
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/chat-widget_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp;Chat with a Librarian</h3>

<p><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 21px;">Need more help? Chat in real-time with a librarian!</span></p>

<div id="libchat_6fd98b6637410ce6805a6efc0cdd5a3d">&nbsp;</div>
<script type="text/javascript" src="https://v2.libanswers.com/load_chat.php?hash=6fd98b6637410ce6805a6efc0cdd5a3d">
    </script></div>

		   </div>
								</div>
								
							</div>
						</div>
					</div>
                    [CONTENT BOX 6884488 NOT FOUND]
                </div>
				</div>
			</section>
        </div>
        <!-- END: content -->
        <!-- BEGIN: Page Footer -->
        <div id="s-lib-footer-public" class="s-lib-footer footer container s-lib-side-borders"><div><div id="s-lib-footer-brand">Powered by Springshare.</div><div id="s-lib-footer-rights">All rights reserved.</div><div id="s-lib-footer-login-link"><a href="https://cpp.libapps.com/libapps/login.php?site_id=1071">Login to LibApps</a></div></div><div id="s-lib-footer-support-link"></div></div></div>
        <!-- END: Page Footer -->
        <div id="s-lib-alert" title="">
                            <div id="s-lib-alert-content"></div>
                       </div>        
                <div id="s-lib-popover-title" class="hide">
                    <span class="text-info"><strong>title</strong></span> 
                    <button type="button" id="popclose" class="close" onclick="jQuery('.s-lib-popover').popover('hide')">&times;</button> 
                </div>
                <div id="s-lib-popover-content" class="hide"><i class="fa fa-refresh fa-spin"></i> Loading...
                    <button class="btn btn-default btn-sm popclose" type="button">Close</button>
                </div>        
			<div id="s-lib-scroll-top" title="Back to Top">
				<span class="fa-stack fa-lg">
				  <i class="fa fa-square-o fa-stack-2x"></i>
				  <i class="fa fa-angle-double-up fa-stack-1x" style="position:relative; bottom:2px;"></i>
				</span>
			</div>        
        <!-- BEGIN: Custom Footer -->
        
<!-- CPP Footer -->
  <footer>
  
<div class="container-fluid" id="cpp-lib-footer">
	<div class="row text-center" id="contact-info">
		<div class="col-xs-12  col-sm-6 col-md-6 col-lg-4 align-self-center">
			<span class="font-weight-bold">University Library
				<br />
		  <a href="https://www.cpp.edu/maps/?id=1130#!m/276533">Building 15</a>
			</span>
		</div>
		<div class="col-xs-12  col-sm-6 col-md-6 col-lg-4 align-self-center">
			<span class="font-weight-bold">
				<a href="mailto:library@cpp.edu">library@cpp.edu</a>
				<br />
		  909-869-3074
			</span>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-1 align-self-center lib-icon">
			<span>
				<a href="http://twitter.com/cpplibrary">
					<img src="https://libapps.s3.amazonaws.com/customers/1060/images/twitter-logo.png" alt="twitter logo" width="32" />
				</a>
			</span>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-1 align-self-center lib-icon">
			<span>
				<a href="http://www.facebook.com/pages/Pomona-CA/Cal-Poly-Pomona-University-Library/13632547215">
					<img src="https://libapps.s3.amazonaws.com/customers/1060/images/facebook-logo.png" alt="facebook logo" width="32" />
				</a>
			</span>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-1 align-self-center lib-icon">
			<span>
				<a href="http://www.youtube.com/user/TheCPPLibrary">
					<img src="https://libapps.s3.amazonaws.com/customers/1060/images/youtube-logo.png" alt="youtube logo" width="32" />
				</a>
			</span>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-1 align-self-center lib-icon">
			<span>
				<a href="https://www.instagram.com/cpplibrary/">
					<img src="https://libapps.s3.amazonaws.com/customers/1060/images/instagram-logo.png" alt="instagram logo" width="32" />
				</a>
			</span>
		</div>
	</div>
</div>
 

</footer>

	<!-- End CPP Footer -->

        <!-- END: Custom Footer -->
	<!-- BEGIN: Analytics code --><script>  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');  ga('create', 'UA-18522228-1', 'auto');  ga('send', 'pageview');</script><!-- END: Analytics code --></body></html>