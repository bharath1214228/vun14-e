<!DOCTYPE html><html lang="en"><head><meta http-equiv="X-UA-Compatible" content="IE=Edge" /><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><!-- write_head_public.twig -->
<title>
    Subjects - Guides at California State Polytechnic University, Pomona
</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noarchive"/>

<!-- favicon.twig -->
<link rel="apple-touch-icon" sizes="180x180" href="//libapps.s3.amazonaws.com/apps/common/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="//libapps.s3.amazonaws.com/apps/common/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="//libapps.s3.amazonaws.com/apps/common/favicon/favicon-16x16.png">
<link rel="manifest" href="//libapps.s3.amazonaws.com/apps/common/favicon/site.webmanifest">
<link rel="mask-icon" href="//libapps.s3.amazonaws.com/apps/common/favicon/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="//libapps.s3.amazonaws.com/apps/common/favicon/favicon.ico">
<meta name="msapplication-TileColor" content="#ffc40d">
<meta name="msapplication-config" content="//libapps.s3.amazonaws.com/apps/common/favicon/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- !favicon.twig -->

<link rel="stylesheet" href="/web/jquery/css/jquery-ui.min.css?2695"/>
<link rel="stylesheet" href="/web/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="/web/css2.18.6/lg-public.min.css"/>
<script src="/web/jquery/js/1.12.4_jquery.min.js"></script>
<!-- js_include_fallback_lg.twig -->
<script src="//code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script>jQuery.ui || document.write('<script src="/web/jquery/js/jquery-ui.min.js?2695">\x3C/script>');</script>
<!-- !js_include_fallback_lg.twig -->
    <script type="text/javascript"
            src="/web/js2.18.6/lg-public.min.js"></script>
<!-- !write_head_public.twig --><script>
	function searchPrimo() {
		document.getElementById("primoQuery").value = "any,contains," + document.getElementById("primoQueryTemp").value.replace(/[,]/g, " ");
		document.forms["searchForm"].submit();
	}
</script>
<style>
body {
margin: 0;
padding-left: 0;
padding-right: 0;
font-size: 15px;
font-family: sans-serif;
}

/* Changing basic link color for contrast */

.s-lg-tab-content  a {
color: #2449b7 !important;
}

.s-lg-boxnav > li > a  {
color: #2449b7 !important;
}

.s-lib-box-content a {
color: #2449b7 !important;
}

a.btn.btn-info.s-lg-hp-btn-section {
color: #FFF !important;
}

a.label-info {
color: #fff !important;
}

/*******************/
.s-lib-box .s-lib-box-title {
font-size: 16px;
}
.s-lib-box-content p, .s-lib-box-content a {
font-size: 15px;
font-family: sans-serif;
}
#cpp-logobar {
width: 100%;
top: 0;
background-color: rgba(244, 244, 244, 0.9);
transition: background-color .7s;
height: 60px;
line-height: 60px;
padding-left: 15px;
}

.align-middle {
vertical-align: middle !important;
}

#cpp-logo-octo {
left: -25px;
top:-15px;
position: relative;
height: 90px;
}

#cpp-libguides {
margin-bottom: 0px;
}

#cpp-links > li > a {
font-size: 16px;
color: #464a4c;
}

#cpp-links a:hover, #cpp-links a:focus {
text-decoration: underline;
}

div#cpp-search {
background-color: #01426a;
font-size: 16px;
margin-top: 0px;
padding-top: 15px;
padding-bottom: 10px;
}


div#cpp-search a {
color: #FFF;
}

img#onesearch {
margin-top: -5px;
margin-left: 15px;
}

#cpp-form {
margin-top: 12px;
margin-right: 5px;
}

input#primoQueryTemp {
margin-left: 10px;
}
div.search-xtra {
margin-top: 17px;
}

#cpp-lib-footer {
background-color: #01426a;
font-size: 1.45em;
color: #FFF;
font-weight: bold;
}
#cpp-lib-footer a {
color: #ffb500;
}
#cpp-lib-footer a:hover, #cpp-lib-footer a:focus {
color: #fff;
text-decoration: underline:
}
#contact-info {
padding-top: 20px;
padding-bottom: 20px;
}
.lib-icon {
margin-top: 15px;
}

/* Made Librarian name larger in profile box */
.s-lib-profile-name {
font-size: 1.6em;
}

/* Make breadcrumb links larger */
#s-lib-admin-bc .breadcrumb, #s-lib-bc .breadcrumb {
font-size: 12px;
}
</style><script>
var springStats = springStats || {};
springStats.saConfig = springStats.saConfig || {
    site_id: 1071,
    tracking_parameters: {"_st_site_id":1071},
    tracking_server_host: "libguides-proc.springyaws.com"
};
</script>
<script async  src="/web/js/sa.min.js?3116" ></script>
            <script type="text/javascript">
                //====================================================
                jQuery(document).ready(function() {
					loadSubjectGuides(0);
                });
                //====================================================
				loadSubjectGuides=function(subject_id) {
					var is_subject = (subject_id != 0);
					jQuery("#s-lg-sb-content-guides").html("<div class=\"bold s-lib-color-lt-grey pad-top-med text-center\">Loading...</div>");
					jQuery("#s-lg-sb-content-databases").html("<div class=\"bold s-lib-color-lt-grey pad-top-med text-center\">Loading...</div>");
					jQuery("#s-lg-sb-experts-div").html("<div class=\"bold s-lib-color-lt-grey pad-top-med text-center\">Loading...</div>");
					
					if (is_subject) {
						jQuery.ajax({
							url: "/sb_process.php",
							dataType: "json",
							data: {
								action: 540,
								subject_id: subject_id
							},
							success: function(response, textStatus) {
								if ( response.errCode == 200 ) {
									jQuery("#s-lg-sb-content-guides").html(response.data.guides);
									jQuery("#s-lg-sb-content-databases").html(response.data.databases);
									jQuery("#s-lg-sb-experts-div").html(response.data.experts);
									jQuery("#s-lg-sb-content-blog-posts").html(response.data.blog_posts);
									jQuery("#s-lg-sb-content-er-courses").html(response.data.er_courses);
								}
								// Init popovers.
								springSpace.UI.xhrPopover();
								springSpace.UI.initPopOvers();
								jQuery(".az-bs-tooltip").tooltip();
							},
							error: function (jqXHR, textStatus, errorThrown) {
							    springSpace.UI.error(errorThrown);
							}
						});
					}
				}
                //====================================================jQuery(window).one('load', function() {springSpace.springTrack.trackPage({_st_type_id: '21'});});</script><style>h2.muted { font-size: 18px; }</style></head><body class="s-lib-public-body">
		<a id="s-lg-public-skiplink" class="alert-info" href="#s-lib-public-main">Skip to Main Content</a>
        <!-- BEGIN: Page Header -->
            <div class="cpp-logobar-min" id="cpp-logobar">
	  <div class="mr-auto">
		<a class="logo align-middle" href="https://www.cpp.edu/index.shtml" id="cpp-header-logo-link"> <img alt="Cal Poly Pomona with Octagon" id="cpp-logo-octo" src="https://libapps.s3.amazonaws.com/customers/1060/images/cpp-octo-web.png"> </a>
	  </div>
	</div>
	<nav class="navbar navbar-default" style="background-color: #fff;" id="cpp-libguides">
  <div class="container-fluid">
	<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	  </button>
	  <a class="navbar-brand" href="https://www.cpp.edu/library/index.shtml" id="brand">
		<img class="img-responsive" alt="University Library" src="https://libapps.s3.amazonaws.com/customers/1060/images/library-justus-small.png" id="logo-img">
	  </a>
	</div>
	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	  <ul class="nav navbar-nav navbar-right" id="cpp-links">
		<li><a href="https://www.cpp.edu/library/library-research-help.shtml">Research Help</a></li>
		<li><a href="https://www.cpp.edu/library/library-services.shtml">Services</a></li>
                <li><a href="https://www.cpp.edu/library/library-spaces-tech.shtml">Spaces &amp; Tech</a></li>
		<li><a href="https://www.cpp.edu/library/library-about.shtml">About</a></li>
		<li><a href="https://www.cpp.edu/library/about/support-library/giving.shtml">Give to the Library</a></li>
	  </ul>
	</div>
  </div>
</nav> <!-- navigation -->
<div class="container-fluid" id="cpp-search">
<div class="row">
  <div class="col-lg-6 col-md-6 12col-sm-12 col-xs-12">
		<form class="form-horizontal" action="https://csu-cpp.primo.exlibrisgroup.com/discovery/search" enctype="application/x-www-form-urlencoded; charset=utf-8" id="simple" method="get" name="searchForm" onsubmit="searchPrimo()" target="_self">
	  <div class="form-group" id="cpp-form">
			<img src="https://libapps.s3.amazonaws.com/customers/1060/images/pomona175.png" class="img-responsive pull-left" alt="OneSearch logo" id="onesearch">
		<div class="input-group">
                <!-- Customizable Parameters -->
                <input type="hidden" name="vid" value="01CALS_PUP:01CALS_PUP" />
                <input type="hidden" name="tab" value="Everything" />
                <input type="hidden" name="search_scope" value="Everything" />
                <input type="hidden" name="lang" value="en" />
                <!-- Fixed parameters -->
                <input type="hidden" name="query" id="primoQuery" />
		  <input class="form-control" id="primoQueryTemp" name="primoQueryTemp" placeholder="Search for books, articles, and more" title="Search CPP Library for books, articles, and more" type="text" />
		  <!-- Search Button -->
		<span class="input-group-btn">
		<button class="btn btn-default" type="button" onclick="searchPrimo()">Go!</button>
	  </span>
		</div>
	  </div>
	</form>
  </div>
  <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 text-center search-xtra"><a href="https://csu-cpp.primo.exlibrisgroup.com/discovery/search?vid=01CALS_PUP:01CALS_PUP&lang=en&mode=advanced">Advanced Search</a></div>
  <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 text-center search-xtra"><a href="https://reserves.calstate.edu/pomona/">Course Reserves</a></div>
  <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 text-center search-xtra"><a href="https://csu-cpp.primo.exlibrisgroup.com/discovery/account?vid=01CALS_PUP:01CALS_PUP">My Library Account</a></div>
</div>
</div>
        <!-- END: Page Header -->
        <!-- BEGIN: Content Header -->
        <div id="s-lib-public-header" class="s-lib-header container s-lib-side-borders">
            <div id="s-lib-bc">
                <ol id="s-lib-bc-list" class="breadcrumb"><li id="s-lib-bc-customer"><a title="University Library" href="http://www.cpp.edu/library">University Library</a></li><li id="s-lib-bc-site"><a title="Guides" href="https://libguides.library.cpp.edu/">Guides</a></li><li id="s-lib-bc-page" class="active">Subjects</li></ol>
            </div>
            <h1 id="s-lib-public-header-title">Subjects</h1>
            <div id="s-lib-public-header-desc">Browse our best resources, organized by subject</div>
        </div>
        <!-- END: Content Header -->
        <!-- BEGIN: Nav Bar -->
        <div id="s-lib-public-nav" class="container s-lib-side-borders">
            
        </div>
        <!-- END: Nav Bar -->
        <!-- BEGIN: content -->
        <div id="s-lib-public-main" class="s-lib-main container s-lib-side-borders">
            <section>
				<div  id="s-lg-sb-search-bar"  class="row">
					<div  id="sb-search-col-1"  class="col-md-12 center">
						<!-- sb_navbar.twig -->
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle pad-right-med" data-toggle="collapse"
                    data-target="#s-lg-sb-nav-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div id="s-lg-sb-label" class="navbar-brand">
                <span id="s-lg-sb-count" class="badge" style="margin-left:10px;">71</span>
                <span id="s-lg-sb-label-text">SUBJECTS</span>
            </div>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="s-lg-sb-nav-1">
            <div class="navbar-form navbar-left" role="search" style="margin-top:8px;">
                <div class="form-group row">
                    <div class="col-md-10" style="display:inline-block;">
                        <label class="control-label sr-only" for="sel-guide-drop">Guide Subject Filter</label>
                        <select name="sel-guide-drop" id="sel-guide-drop" class="form-control" style="width:100%;">
                                                            <option selected value="">Select a Subject...</option>
                                                        <option value="sb.php?subject_id=60012" >Accounting</option>
                            <option value="sb.php?subject_id=77586" >Aerospace Engineering</option>
                            <option value="sb.php?subject_id=60013" >Agribusiness & Food Industry Management</option>
                            <option value="sb.php?subject_id=139681" >Agricultural Education</option>
                            <option value="sb.php?subject_id=60014" >Agriculture</option>
                            <option value="sb.php?subject_id=60015" >Animal & Veterinary Science</option>
                            <option value="sb.php?subject_id=139683" >Animal Science</option>
                            <option value="sb.php?subject_id=60016" >Anthropology</option>
                            <option value="/amm" >Apparel Merchandising & Management</option>
                            <option value="sb.php?subject_id=60017" >Architecture</option>
                            <option value="sb.php?subject_id=60018" >Art</option>
                            <option value="sb.php?subject_id=60020" >Biological Sciences</option>
                            <option value="sb.php?subject_id=60021" >Business Administration</option>
                            <option value="sb.php?subject_id=77587" >Chemical Engineering</option>
                            <option value="sb.php?subject_id=60022" >Chemistry & Biochemistry</option>
                            <option value="sb.php?subject_id=77585" >Civil Engineering</option>
                            <option value="sb.php?subject_id=50005" >Communication</option>
                            <option value="sb.php?subject_id=60024" >Computer Information Systems</option>
                            <option value="sb.php?subject_id=60025" >Computer Science</option>
                            <option value="/ecs" >Early Childhood Studies</option>
                            <option value="sb.php?subject_id=60026" >Economics</option>
                            <option value="/education" >Education</option>
                            <option value="sb.php?subject_id=77589" >Electrical & Computer Engineering</option>
                            <option value="sb.php?subject_id=50003" >Engineering</option>
                            <option value="sb.php?subject_id=77590" >Engineering Technology</option>
                            <option value="sb.php?subject_id=60028" >English</option>
                            <option value="sb.php?subject_id=60029" >Environmental Design</option>
                            <option value="/e-w-s" >Ethnic & Women’s Studies</option>
                            <option value="sb.php?subject_id=139685" >Film &Television</option>
                            <option value="sb.php?subject_id=107387" >Finance</option>
                            <option value="sb.php?subject_id=60031" >Food Science</option>
                            <option value="sb.php?subject_id=60032" >Geography</option>
                            <option value="sb.php?subject_id=60033" >Geological Sciences</option>
                            <option value="sb.php?subject_id=139698" >Government</option>
                            <option value="sb.php?subject_id=60035" >History</option>
                            <option value="sb.php?subject_id=60036" >Hospitality Management</option>
                            <option value="sb.php?subject_id=77591" >Industrial & Manufacturing Engineering</option>
                            <option value="sb.php?subject_id=139684" >Information Technology</option>
                            <option value="sb.php?subject_id=60038" >Interdisciplinary General Education</option>
                            <option value="sb.php?subject_id=60039" >International Business</option>
                            <option value="sb.php?subject_id=139696" >Journalism</option>
                            <option value="sb.php?subject_id=60041" >Kinesiology & Health Promotion</option>
                            <option value="/subject/landscape-architecture" >Landscape Architecture</option>
                            <option value="sb.php?subject_id=139703" >Language & Linguistics</option>
                            <option value="sb.php?subject_id=60042" >Law</option>
                            <option value="/subject/liberal-studies" >Liberal Studies</option>
                            <option value="sb.php?subject_id=139691" >Literature</option>
                            <option value="sb.php?subject_id=60043" >Management & Human Resources</option>
                            <option value="sb.php?subject_id=139676" >Marketing</option>
                            <option value="sb.php?subject_id=139680" >Materials Engineering</option>
                            <option value="sb.php?subject_id=60044" >Mathematics & Statistics</option>
                            <option value="sb.php?subject_id=77592" >Mechanical Engineering</option>
                            <option value="sb.php?subject_id=193542" >Modern Languages</option>
                            <option value="sb.php?subject_id=139672" >Multi-Subject</option>
                            <option value="/subject/music" >Music</option>
                            <option value="/newspapers" >Newspapers</option>
                            <option value="sb.php?subject_id=60037" >Nutrition</option>
                            <option value="sb.php?subject_id=60046" >Philosophy</option>
                            <option value="sb.php?subject_id=60047" >Physics & Astronomy</option>
                            <option value="sb.php?subject_id=60048" >Plant Science</option>
                            <option value="sb.php?subject_id=60049" >Political Science</option>
                            <option value="sb.php?subject_id=50004" >Psychology</option>
                            <option value="/public-administration" >Public Administration</option>
                            <option value="sb.php?subject_id=60050" >Reference</option>
                            <option value="/subject/regenerative-studies" >Regenerative Studies</option>
                            <option value="sb.php?subject_id=181168" >Science</option>
                            <option value="sb.php?subject_id=60052" >Sociology</option>
                            <option value="sb.php?subject_id=193544" >Special Collections and Archives</option>
                            <option value="sb.php?subject_id=60053" >Technology & Operations Management</option>
                            <option value="/subject/theatre" >Theatre & New Dance</option>
                            <option value="sb.php?subject_id=60054" >Urban & Regional Planning</option>
                                                    </select>
                    </div>
                    <div class="col-md-2 pad-left-none" style="display:inline-block;">
                        <button type="button" class="btn btn-small btn-primary"
                                onclick="window.location.href = (jQuery('#sel-guide-drop').val());">
                            Go
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>
					</div>
				</div>
			</section>
			<section>
				<div  id="s-lg-sb-cols"  class="row">
					<div  id="col1"  class="col-md-8 center">
						
					</div>
					<div  id="col2"  class="col-md-4 center">
						<div style="padding-top: 9px;"></div>
						
					<div id="s-lg-box-6884485-container" class="s-lib-box-container">
						<div id="s-lg-box-6884485" class="s-lib-box s-lib-box-std">
							<h2 class="s-lib-box-title">GET HELP
                                </h2>
							<div id="s-lg-box-collapse-6884485" >
								<div class="s-lib-box-content">
									
			<div id="s-lg-content-13672496" class="  clearfix">
				<div style="height:100%;padding-bottom: 30px;">
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/call-widget_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp;Call us!</h3>

<p><span style="font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;">Call the <a href="https://cpp.service-now.com/library?id=library_article&amp;sys_id=9a0795b3db78df04ae3a567b4b96193f" target="_self">Research Help Desk</a> @ </span><span style=" font-weight: 700; font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;">(909) 869-3084</span><span style="font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;"> </span></p>

<hr />
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/help-widgit_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp; Visit us!</h3>

<p><span style="font-size:14px;"><span style="font-family: Roboto,Arial,serif; line-height: 21px;">Drop in at the <a href="https://cpp.service-now.com/library?id=library_article&amp;sys_id=9a0795b3db78df04ae3a567b4b96193f" target="_self">Research Help Desk</a> </span>on the 2nd Floor of the University Library.</span></p>

<hr />
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/find-widget_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp; Find a Subject Librarian</h3>

<p><span style="font-size:14px;"><span style="font-family: Roboto,Arial,serif; line-height: 21px;"><a href="https://www.cpp.edu/library/reference-instruction/contact-subject-librarian.shtml" target="_self">Subject Librarians</a> </span><span style="font-family: Roboto,Arial,serif; line-height: 21px;"></span>can help with in-depth research</span></p>

<hr />
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/text-widget_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp;Text a Librarian</h3>

<p><span style="font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;">Text or email us at </span><span style="font-weight: 700; font-family: Roboto, Arial, serif; font-size: 14px; line-height: 21px;"><a href="mailto:libraryhelp@cpp.edu">libraryhelp@cpp.edu</a></span></p>

<hr />
<h3><img alt="" loading="lazy" src="https://libapps.s3.amazonaws.com/accounts/2555/images/chat-widget_blue.png" style="float: left; width: 30px; height: 30px;" />&nbsp;Chat with a Librarian</h3>

<p><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 21px;">Need more help? Chat in real-time with a librarian!</span></p>

<div id="libchat_6fd98b6637410ce6805a6efc0cdd5a3d">&nbsp;</div>
<script type="text/javascript" src="https://v2.libanswers.com/load_chat.php?hash=6fd98b6637410ce6805a6efc0cdd5a3d">
    </script></div>

		   </div>
								</div>
								
							</div>
						</div>
					</div>
                                                [CONTENT BOX 6884488 NOT FOUND]
					</div>
				</div>
			</section>
        </div>
        <!-- END: content -->
        <!-- BEGIN: Page Footer -->
        <div id="s-lib-footer-public" class="s-lib-footer footer container s-lib-side-borders"><div><div id="s-lib-footer-brand">Powered by Springshare.</div><div id="s-lib-footer-rights">All rights reserved.</div><div id="s-lib-footer-login-link"><a href="https://cpp.libapps.com/libapps/login.php?site_id=1071">Login to LibApps</a></div></div><div id="s-lib-footer-support-link"></div></div></div>
        <!-- END: Page Footer -->
        <div id="s-lib-alert" title="">
                            <div id="s-lib-alert-content"></div>
                       </div>        
                <div id="s-lib-popover-title" class="hide">
                    <span class="text-info"><strong>title</strong></span> 
                    <button type="button" id="popclose" class="close" onclick="jQuery('.s-lib-popover').popover('hide')">&times;</button> 
                </div>
                <div id="s-lib-popover-content" class="hide"><i class="fa fa-refresh fa-spin"></i> Loading...
                    <button class="btn btn-default btn-sm popclose" type="button">Close</button>
                </div>        
			<div id="s-lib-scroll-top" title="Back to Top">
				<span class="fa-stack fa-lg">
				  <i class="fa fa-square-o fa-stack-2x"></i>
				  <i class="fa fa-angle-double-up fa-stack-1x" style="position:relative; bottom:2px;"></i>
				</span>
			</div>        
        <!-- BEGIN: Custom Footer -->
        
<!-- CPP Footer -->
  <footer>
  
<div class="container-fluid" id="cpp-lib-footer">
	<div class="row text-center" id="contact-info">
		<div class="col-xs-12  col-sm-6 col-md-6 col-lg-4 align-self-center">
			<span class="font-weight-bold">University Library
				<br />
		  <a href="https://www.cpp.edu/maps/?id=1130#!m/276533">Building 15</a>
			</span>
		</div>
		<div class="col-xs-12  col-sm-6 col-md-6 col-lg-4 align-self-center">
			<span class="font-weight-bold">
				<a href="mailto:library@cpp.edu">library@cpp.edu</a>
				<br />
		  909-869-3074
			</span>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-1 align-self-center lib-icon">
			<span>
				<a href="http://twitter.com/cpplibrary">
					<img src="https://libapps.s3.amazonaws.com/customers/1060/images/twitter-logo.png" alt="twitter logo" width="32" />
				</a>
			</span>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-1 align-self-center lib-icon">
			<span>
				<a href="http://www.facebook.com/pages/Pomona-CA/Cal-Poly-Pomona-University-Library/13632547215">
					<img src="https://libapps.s3.amazonaws.com/customers/1060/images/facebook-logo.png" alt="facebook logo" width="32" />
				</a>
			</span>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-1 align-self-center lib-icon">
			<span>
				<a href="http://www.youtube.com/user/TheCPPLibrary">
					<img src="https://libapps.s3.amazonaws.com/customers/1060/images/youtube-logo.png" alt="youtube logo" width="32" />
				</a>
			</span>
		</div>
		<div class="col-xs-3 col-sm-3 col-md-3 col-lg-1 align-self-center lib-icon">
			<span>
				<a href="https://www.instagram.com/cpplibrary/">
					<img src="https://libapps.s3.amazonaws.com/customers/1060/images/instagram-logo.png" alt="instagram logo" width="32" />
				</a>
			</span>
		</div>
	</div>
</div>
 

</footer>

	<!-- End CPP Footer -->

        <!-- END: Custom Footer -->
	<!-- BEGIN: Analytics code --><script>  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');  ga('create', 'UA-18522228-1', 'auto');  ga('send', 'pageview');</script><!-- END: Analytics code --></body></html>